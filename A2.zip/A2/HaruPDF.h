/*
 * Written By: Tyler Dailey, for Assignment 2, CS3505, 9/5/16
 */
class HaruPDF {
public:
    HaruPDF();
    void placeCharacter(char);
    void save(char*);
    void newDocument(char*);
    void advancePosition(double, double, double);
};
